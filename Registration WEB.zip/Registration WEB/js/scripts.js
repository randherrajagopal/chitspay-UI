(function($){

	"use strict";
	  
	$(document).ready(function () {
		bookyourtravel.init();
	});
	
	$(window).on('load', function() {
		bookyourtravel.load();
	});
	
	var bookyourtravel = {
	
		init: function () {
			
			//MAIN SEARCH 
	
			
			//SEARCH WIDGET
		
			
			// MOBILE MENU
			$('#nav').slimmenu({
				resizeWidth: '1040',
				collapserTitle: 'Main Menu',
				animSpeed: 'medium',
				easingEffect: null,
				indentChildren: false,
				childrenIndenter: '&nbsp;',
				expandIcon:'<i class="material-icons">keyboard_arrow_right</i>',
				collapseIcon:'<i class="material-icons">expand_less</i>'
			});
			
			// CUSTOM FORM ELEMENTS
			
			//UI FORM ELEMENTS
			
			
			//SCROLL TO TOP BUTTON
			
			//HEADER RIBBON NAVIGATION
			
			//TABS
			
			
			//ROOM TYPES MORE BUTTON
			
					
			
			//LOGIN & REGISTER LIGHTBOX
			
			//CONTACT FORM
		
			
			// PRELOADER
			
		},
	
	}

})(jQuery);